# @Title: Delete Messages via EWS OAuth with Application Type Permission (Exchange Online).
# @Author: Kuiyuan
# @Date: 2023.12.21

########### >>> Request Access_Token >>> ############ 

# EWS OAuth App-Only Authentication

## >>> Customize >>>
param(
    [string] $TenantID = "",
    [string] $AppId = "",
    [string] $AppSecret = "",

    [string] $TargetFolderName = "RecoverableItemsDeletions",
)

Add-Type -Path 'C:\temp\Microsoft.IdentityModel.Clients.ActiveDirectory.dll';
Add-Type -Path "C:\temp\Microsoft.Exchange.WebServices.dll";

$exportCsvPath = "C:\temp\DeleteMessageReport_v1.csv"
$MbCsvPath = "C:\temp\targetMailboxList_v1.csv"
[Array]$targetMailboxList = Import-Csv -Path $MbCsvPath

## <<< Customize <<<

$authString = "https://login.microsoftonline.com/$TenantID";

# this part uses the classes to obtain the necessary security token for performing our operations against the Graph API
$creds = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.ClientCredential" -ArgumentList $AppId, $AppSecret;
$authContext = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext"-ArgumentList $authString;
$context = $authContext.AcquireTokenAsync("https://outlook.office365.com/", $creds).Result;
$acc_token = $context.AccessToken;

############ <<< Request Access_Token <<< ###########

## Loop all mailboxes in the TargetMailboxCsv file
$MbCnt = $targetMailboxList.Count
$DeleteResult = @()
$TotalItemCnt = 0

## Create the Exchange Service object with Oauth creds
$EWSService = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService -ArgumentList Exchange2010_SP2
$EWSService.Url= new-object Uri("https://outlook.office365.com/EWS/Exchange.asmx")

for($i = 0; $i -lt $MbCnt; $i ++){

    $TargetMailboxUpn = $targetMailboxList[$i].UserPrincipalName
    Write-Host "--> Target Mailbox: $TargetMailboxUpn" -ForegroundColor Green

    $EWSService.HttpHeaders.Clear()
    #$EWSService.TraceEnabled = $true
    $EWSService.ImpersonatedUserId = new-object Microsoft.Exchange.WebServices.Data.ImpersonatedUserId([Microsoft.Exchange.WebServices.Data.ConnectingIdType]::SmtpAddress,$TargetMailboxUpn)
    $EWSService.HttpHeaders.Add("X-AnchorMailbox", $TargetMailboxUpn)

    # >>> !!! Use the Access_Token for EWS Object. !!!
    $EWSService.Credentials = New-Object Microsoft.Exchange.WebServices.Data.OAuthCredentials($acc_token);
    # <<< !!! Use the Access_Token for EWS Object. !!!

    $TargetFolderId = new-object Microsoft.Exchange.WebServices.Data.FolderId([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::$TargetFolderName, $TargetMailboxUPN);
    $targetFolder=[Microsoft.Exchange.WebServices.Data.Folder]::Bind($EWSService,$TargetFolderId);

    $ItemView = New-Object Microsoft.Exchange.WebServices.Data.ItemView(1000)

    $fiItems = $null
    $itemCnt = 0
    $PageCnt = 1

    do{  

        $fiItems = $EWSService.FindItems($targetFolder.Id, $ItemView)
        $curItmeCnt = $fiItems.Items.Count       
        
        $TotalItemCnt += $curItmeCnt
        Write-Host "  |--> Find item count: $curItmeCnt in page $PageCnt" -ForegroundColor Cyan

        for($j1 = 0; $j1 -lt $curItmeCnt; $j1++){

            Write-Progress -PercentComplete (($j1 + 1) / $curItemCnt * 100) -Activity "Deleting Item $($j1+1) of $curItemCnt in $TargetMailboxUpn Folder Name: $TargetFolderName, page: $PageCnt"
            $curItem = $fiItems.Items[$j]
            
            <#
            $tmpObj = [PSCustomObject]@{
                UPN = $TargetMailboxUpn
                MessageSuject = $curItem.Subject
                ReceiveDateTime = $curItem.DateTimeReceived.DateTime
            }

            $DeleteResult += $tmpObj
            #>

            $curItem.Delete('HardDelete')
            ## Types of Deletes - HardDelete,MoveToDeletedItems,SoftDelete
            $PageCnt ++
        }
        $ItemView.Offset += $fiItems.Items.Count
    } while($fiItems.MoreAvailable -eq $true)

}

Write-Host "Delete Action done for items count: $TotalItemCnt" -ForegroundColor Green